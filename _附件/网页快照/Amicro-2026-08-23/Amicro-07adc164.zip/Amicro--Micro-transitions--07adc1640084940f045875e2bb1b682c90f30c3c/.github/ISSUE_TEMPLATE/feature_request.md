---
name: ✨ Feature request
about: Suggest an idea or a new micro-transition for this library
title: '[FEATURE] '
labels: enhancement
assignees: ''

---

**Is your feature request related to a problem? Please describe.**
A clear and concise description of what the problem is. E.g. "I'm frustrated when [...]"

**Describe the solution you'd like**
A clear and concise description of what you want to happen. E.g. "A springy text interaction that morphs on click [...]"

**Describe alternatives you've considered**
A clear and concise description of any alternative solutions or features you've considered.

**Additional context**
Add any other context, design mockups, or Framer Motion references about the feature request here.
