"use client";

import { motion, useReducedMotion } from "motion/react";
import { usePathname } from "next/navigation";
import { type ReactNode, useEffect, useRef, useState } from "react";
import { EASE_OUT } from "@/lib/ease";

export function PageTransition({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const reduce = useReducedMotion();
  // Component and guide pages contain viewport-fixed navigation. Translating an
  // ancestor makes fixed descendants anchor to that moving element during the
  // transition instead of the viewport.
  const hasViewportFixedContent =
    pathname.startsWith("/components/") || pathname.startsWith("/docs/") || pathname.startsWith("/charts") || pathname.startsWith("/playground");
  const shouldTranslate = !reduce && !hasViewportFixedContent;
  const ref = useRef<HTMLDivElement>(null);
  // Skip enter animation on first load so LCP element is visible immediately.
  // After mount, navigations animate normally.
  const [mounted, setMounted] = useState(false);
  useEffect(() => { setMounted(true); }, []);

  return (
    <motion.div
      ref={ref}
      key={pathname}
      initial={
        mounted
          ? shouldTranslate
            ? { opacity: 0, y: 24 }
            : { opacity: 0 }
          : false
      }
      animate={shouldTranslate ? { opacity: 1, y: 0 } : { opacity: 1 }}
      transition={{ duration: shouldTranslate ? 0.6 : 0.2, ease: EASE_OUT }}
      onAnimationComplete={() => {
        const el = ref.current;
        if (!el) return;
        el.style.transform = "none";
        el.style.willChange = "auto";
      }}
    >
      {children}
    </motion.div>
  );
}
