package asc

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strings"
)

// GetSubscriptionGroups retrieves the list of subscription groups for an app.
func (c *Client) GetSubscriptionGroups(ctx context.Context, appID string, opts ...SubscriptionGroupsOption) (*SubscriptionGroupsResponse, error) {
	query := &subscriptionGroupsQuery{}
	for _, opt := range opts {
		opt(query)
	}

	path := fmt.Sprintf("/v1/apps/%s/subscriptionGroups", strings.TrimSpace(appID))
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionGroups: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildSubscriptionGroupsQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionGroupsResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// CreateSubscriptionGroup creates a subscription group for an app.
func (c *Client) CreateSubscriptionGroup(ctx context.Context, appID string, attrs SubscriptionGroupCreateAttributes) (*SubscriptionGroupResponse, error) {
	payload := SubscriptionGroupCreateRequest{
		Data: SubscriptionGroupCreateData{
			Type:       ResourceTypeSubscriptionGroups,
			Attributes: attrs,
			Relationships: &SubscriptionGroupRelationships{
				App: &Relationship{
					Data: ResourceData{
						Type: ResourceTypeApps,
						ID:   strings.TrimSpace(appID),
					},
				},
			},
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}

	data, err := c.do(ctx, http.MethodPost, "/v1/subscriptionGroups", body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionGroupResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionGroup retrieves a subscription group by ID.
func (c *Client) GetSubscriptionGroup(ctx context.Context, groupID string, opts ...SubscriptionGroupsOption) (*SubscriptionGroupResponse, error) {
	groupID = strings.TrimSpace(groupID)
	if groupID == "" {
		return nil, fmt.Errorf("groupID is required")
	}
	query := &subscriptionGroupsQuery{}
	for _, opt := range opts {
		opt(query)
	}
	if query.limit > 0 {
		return nil, fmt.Errorf("limit is only supported when listing subscription groups")
	}
	if query.nextURL != "" {
		return nil, fmt.Errorf("next URL is only supported when listing subscription groups")
	}

	path := fmt.Sprintf("/v1/subscriptionGroups/%s", groupID)
	if queryString := buildSubscriptionGroupsQuery(query); queryString != "" {
		path += "?" + queryString
	}
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionGroupResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// UpdateSubscriptionGroup updates a subscription group.
func (c *Client) UpdateSubscriptionGroup(ctx context.Context, groupID string, attrs SubscriptionGroupUpdateAttributes) (*SubscriptionGroupResponse, error) {
	payload := SubscriptionGroupUpdateRequest{
		Data: SubscriptionGroupUpdateData{
			Type:       ResourceTypeSubscriptionGroups,
			ID:         strings.TrimSpace(groupID),
			Attributes: attrs,
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}

	path := fmt.Sprintf("/v1/subscriptionGroups/%s", strings.TrimSpace(groupID))
	data, err := c.do(ctx, http.MethodPatch, path, body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionGroupResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// DeleteSubscriptionGroup deletes a subscription group.
func (c *Client) DeleteSubscriptionGroup(ctx context.Context, groupID string) error {
	path := fmt.Sprintf("/v1/subscriptionGroups/%s", strings.TrimSpace(groupID))
	_, err := c.do(ctx, http.MethodDelete, path, nil)
	return err
}

// GetSubscriptions retrieves the list of subscriptions for a group.
func (c *Client) GetSubscriptions(ctx context.Context, groupID string, opts ...SubscriptionsOption) (*SubscriptionsResponse, error) {
	query := &subscriptionsQuery{}
	for _, opt := range opts {
		opt(query)
	}

	path := fmt.Sprintf("/v1/subscriptionGroups/%s/subscriptions", strings.TrimSpace(groupID))
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptions: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildSubscriptionsQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionsResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// CreateSubscription creates a subscription within a group.
func (c *Client) CreateSubscription(ctx context.Context, groupID string, attrs SubscriptionCreateAttributes) (*SubscriptionResponse, error) {
	payload := SubscriptionCreateRequest{
		Data: SubscriptionCreateData{
			Type:       ResourceTypeSubscriptions,
			Attributes: attrs,
			Relationships: &SubscriptionRelationships{
				Group: &Relationship{
					Data: ResourceData{
						Type: ResourceTypeSubscriptionGroups,
						ID:   strings.TrimSpace(groupID),
					},
				},
			},
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}

	data, err := c.do(ctx, http.MethodPost, "/v1/subscriptions", body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscription retrieves a subscription by ID.
func (c *Client) GetSubscription(ctx context.Context, subID string, opts ...SubscriptionOption) (*SubscriptionResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}
	query := &subscriptionQuery{}
	for _, opt := range opts {
		opt(query)
	}
	path := fmt.Sprintf("/v1/subscriptions/%s", subID)
	if queryString := buildSubscriptionQuery(query); queryString != "" {
		path += "?" + queryString
	}
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// UpdateSubscription updates a subscription.
func (c *Client) UpdateSubscription(ctx context.Context, subID string, attrs SubscriptionUpdateAttributes) (*SubscriptionResponse, error) {
	payload := SubscriptionUpdateRequest{
		Data: SubscriptionUpdateData{
			Type:       ResourceTypeSubscriptions,
			ID:         strings.TrimSpace(subID),
			Attributes: attrs,
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}

	path := fmt.Sprintf("/v1/subscriptions/%s", strings.TrimSpace(subID))
	data, err := c.do(ctx, http.MethodPatch, path, body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// SetSubscriptionPriceMatrix atomically sets an initial subscription price
// matrix using inline SubscriptionPriceInlineCreate resources.
func (c *Client) SetSubscriptionPriceMatrix(ctx context.Context, subID string, entries []SubscriptionInlinePrice) (*SubscriptionResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}
	if len(entries) == 0 {
		return nil, fmt.Errorf("at least one subscription price is required")
	}

	normalized := make([]SubscriptionInlinePrice, 0, len(entries))
	byTerritory := make(map[string]SubscriptionInlinePrice, len(entries))
	for i, entry := range entries {
		entry.PricePointID = strings.TrimSpace(entry.PricePointID)
		entry.TerritoryID = strings.ToUpper(strings.TrimSpace(entry.TerritoryID))
		entry.Attributes.StartDate = strings.TrimSpace(entry.Attributes.StartDate)
		entry.Attributes.PlanType = SubscriptionPlanType(strings.TrimSpace(string(entry.Attributes.PlanType)))
		if entry.PricePointID == "" {
			return nil, fmt.Errorf("subscription price row %d: price point ID is required", i+1)
		}
		if previous, ok := byTerritory[entry.TerritoryID]; ok {
			if subscriptionPriceMatrixEntriesEqual(previous, entry) {
				continue
			}
			return nil, fmt.Errorf("subscription price matrix has duplicate territory %q with conflicting values", entry.TerritoryID)
		}
		byTerritory[entry.TerritoryID] = entry
		normalized = append(normalized, entry)
	}
	sort.Slice(normalized, func(i, j int) bool {
		return normalized[i].TerritoryID < normalized[j].TerritoryID
	})

	relationshipData := make([]ResourceData, 0, len(normalized))
	included := make([]SubscriptionPriceInlineCreate, 0, len(normalized))
	for i, entry := range normalized {
		inlinePriceID := fmt.Sprintf("${price-%d}", i+1)
		relationshipData = append(relationshipData, ResourceData{
			Type: ResourceTypeSubscriptionPrices,
			ID:   inlinePriceID,
		})

		var attributes *SubscriptionPriceCreateAttributes
		if entry.Attributes.StartDate != "" || entry.Attributes.Preserved != nil || entry.Attributes.PlanType != "" {
			attrs := entry.Attributes
			attributes = &attrs
		}
		relationships := SubscriptionPriceInlineRelationships{
			Subscription:           Relationship{Data: ResourceData{Type: ResourceTypeSubscriptions, ID: subID}},
			SubscriptionPricePoint: Relationship{Data: ResourceData{Type: ResourceTypeSubscriptionPricePoints, ID: entry.PricePointID}},
		}
		if entry.TerritoryID != "" {
			relationships.Territory = &Relationship{
				Data: ResourceData{
					Type: ResourceTypeTerritories,
					ID:   entry.TerritoryID,
				},
			}
		}
		included = append(included, SubscriptionPriceInlineCreate{
			Type:          ResourceTypeSubscriptionPrices,
			ID:            inlinePriceID,
			Attributes:    attributes,
			Relationships: relationships,
		})
	}

	payload := SubscriptionUpdateRequest{
		Data: SubscriptionUpdateData{
			Type: ResourceTypeSubscriptions,
			ID:   subID,
			Relationships: &SubscriptionUpdateRelationships{
				Prices: &RelationshipList{
					Data: relationshipData,
				},
			},
		},
		Included: included,
	}

	path := fmt.Sprintf("/v1/subscriptions/%s", subID)
	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}
	data, err := c.do(ctx, http.MethodPatch, path, body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

func subscriptionPriceMatrixEntriesEqual(a, b SubscriptionInlinePrice) bool {
	if a.PricePointID != b.PricePointID || a.TerritoryID != b.TerritoryID || a.Attributes.StartDate != b.Attributes.StartDate || a.Attributes.PlanType != b.Attributes.PlanType {
		return false
	}
	if a.Attributes.Preserved == nil || b.Attributes.Preserved == nil {
		return a.Attributes.Preserved == nil && b.Attributes.Preserved == nil
	}
	return *a.Attributes.Preserved == *b.Attributes.Preserved
}

// SetSubscriptionInitialPrice sets the initial base price on a subscription that
// has no existing prices. This uses PATCH /v1/subscriptions/{id} with inline
// SubscriptionPriceInlineCreate resources, which is the only supported method
// for setting the first price on a new subscription. POST /v1/subscriptionPrices
// only works for price *changes* on subscriptions that already have a price.
func (c *Client) SetSubscriptionInitialPrice(ctx context.Context, subID, pricePointID, territoryID string, attrs SubscriptionPriceCreateAttributes) (*SubscriptionResponse, error) {
	return c.SetSubscriptionPriceMatrix(ctx, subID, []SubscriptionInlinePrice{{
		PricePointID: pricePointID,
		TerritoryID:  territoryID,
		Attributes:   attrs,
	}})
}

// DeleteSubscription deletes a subscription.
func (c *Client) DeleteSubscription(ctx context.Context, subID string) error {
	path := fmt.Sprintf("/v1/subscriptions/%s", strings.TrimSpace(subID))
	_, err := c.do(ctx, http.MethodDelete, path, nil)
	return err
}

// CreateSubscriptionPrice adds a price to a subscription.
func (c *Client) CreateSubscriptionPrice(ctx context.Context, subID, pricePointID, territoryID string, attrs SubscriptionPriceCreateAttributes) (*SubscriptionPriceResponse, error) {
	subID = strings.TrimSpace(subID)
	pricePointID = strings.TrimSpace(pricePointID)
	territoryID = strings.ToUpper(strings.TrimSpace(territoryID))
	if subID == "" || pricePointID == "" {
		return nil, fmt.Errorf("subscription ID and price point ID are required")
	}

	var attributes *SubscriptionPriceCreateAttributes
	if attrs.StartDate != "" || attrs.Preserved != nil || attrs.PlanType != "" {
		attributes = &attrs
	}

	relationships := &SubscriptionPriceRelationships{
		Subscription: &Relationship{
			Data: ResourceData{
				Type: ResourceTypeSubscriptions,
				ID:   subID,
			},
		},
		SubscriptionPricePoint: &Relationship{
			Data: ResourceData{
				Type: ResourceTypeSubscriptionPricePoints,
				ID:   pricePointID,
			},
		},
	}
	if territoryID != "" {
		relationships.Territory = &Relationship{
			Data: ResourceData{
				Type: ResourceTypeTerritories,
				ID:   territoryID,
			},
		}
	}

	payload := SubscriptionPriceCreateRequest{
		Data: SubscriptionPriceCreateData{
			Type:          ResourceTypeSubscriptionPrices,
			Attributes:    attributes,
			Relationships: relationships,
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}
	data, err := c.do(ctx, http.MethodPost, "/v1/subscriptionPrices", body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionPriceResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// DeleteSubscriptionPrice deletes a subscription price.
func (c *Client) DeleteSubscriptionPrice(ctx context.Context, priceID string) error {
	path := fmt.Sprintf("/v1/subscriptionPrices/%s", strings.TrimSpace(priceID))
	_, err := c.do(ctx, http.MethodDelete, path, nil)
	return err
}

// CreateSubscriptionAvailability sets subscription availability in territories.
func (c *Client) CreateSubscriptionAvailability(ctx context.Context, subID string, territoryIDs []string, attrs SubscriptionAvailabilityAttributes) (*SubscriptionAvailabilityResponse, error) {
	subID = strings.TrimSpace(subID)
	territoryIDs = normalizeList(territoryIDs)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}
	if len(territoryIDs) == 0 {
		return nil, fmt.Errorf("territory IDs are required")
	}

	relData := make([]ResourceData, 0, len(territoryIDs))
	for _, territoryID := range territoryIDs {
		relData = append(relData, ResourceData{
			Type: ResourceTypeTerritories,
			ID:   territoryID,
		})
	}

	payload := SubscriptionAvailabilityCreateRequest{
		Data: SubscriptionAvailabilityCreateData{
			Type:       ResourceTypeSubscriptionAvailabilities,
			Attributes: attrs,
			Relationships: &SubscriptionAvailabilityRelationships{
				Subscription: &Relationship{
					Data: ResourceData{
						Type: ResourceTypeSubscriptions,
						ID:   subID,
					},
				},
				AvailableTerritories: &RelationshipList{Data: relData},
			},
		},
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return nil, err
	}
	data, err := c.do(ctx, http.MethodPost, "/v1/subscriptionAvailabilities", body)
	if err != nil {
		return nil, err
	}

	var response SubscriptionAvailabilityResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionAvailability retrieves a subscription availability by ID.
func (c *Client) GetSubscriptionAvailability(ctx context.Context, availabilityID string) (*SubscriptionAvailabilityResponse, error) {
	availabilityID = strings.TrimSpace(availabilityID)
	if availabilityID == "" {
		return nil, fmt.Errorf("availabilityID is required")
	}

	path := fmt.Sprintf("/v1/subscriptionAvailabilities/%s", availabilityID)
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionAvailabilityResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionAvailabilityForSubscription retrieves availability for a subscription.
func (c *Client) GetSubscriptionAvailabilityForSubscription(ctx context.Context, subID string) (*SubscriptionAvailabilityResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/subscriptionAvailability", subID)
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionAvailabilityResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionAvailabilityAvailableTerritories lists available territories for an availability.
func (c *Client) GetSubscriptionAvailabilityAvailableTerritories(ctx context.Context, availabilityID string, opts ...SubscriptionAvailabilityTerritoriesOption) (*TerritoriesResponse, error) {
	query := &subscriptionAvailabilityTerritoriesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	availabilityID = strings.TrimSpace(availabilityID)
	if query.nextURL == "" && availabilityID == "" {
		return nil, fmt.Errorf("availabilityID is required")
	}

	path := fmt.Sprintf("/v1/subscriptionAvailabilities/%s/availableTerritories", availabilityID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscription-availability-territories: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildSubscriptionAvailabilityTerritoriesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response TerritoriesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionAppStoreReviewScreenshotForSubscription retrieves the review screenshot for a subscription.
func (c *Client) GetSubscriptionAppStoreReviewScreenshotForSubscription(ctx context.Context, subID string, opts ...SubscriptionAppStoreReviewScreenshotOption) (*SubscriptionAppStoreReviewScreenshotResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	query := &subscriptionAppStoreReviewScreenshotQuery{}
	for _, opt := range opts {
		opt(query)
	}
	path := fmt.Sprintf("/v1/subscriptions/%s/appStoreReviewScreenshot", subID)
	if queryString := buildSubscriptionAppStoreReviewScreenshotQuery(query); queryString != "" {
		path += "?" + queryString
	}
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionAppStoreReviewScreenshotResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionPromotedPurchase retrieves the promoted purchase for a subscription.
func (c *Client) GetSubscriptionPromotedPurchase(ctx context.Context, subID string, opts ...PromotedPurchaseGetOption) (*PromotedPurchaseResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	query := &promotedPurchaseGetQuery{}
	for _, opt := range opts {
		opt(query)
	}
	path := fmt.Sprintf("/v1/subscriptions/%s/promotedPurchase", subID)
	if queryString := buildPromotedPurchaseGetQuery(query); queryString != "" {
		path += "?" + queryString
	}
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response PromotedPurchaseResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// SubscriptionAppStoreReviewScreenshotLinkageResponse is the response for app store review screenshot relationship endpoints.
type SubscriptionAppStoreReviewScreenshotLinkageResponse struct {
	Data  ResourceData `json:"data"`
	Links Links        `json:"links"`
}

// SubscriptionPromotedPurchaseLinkageResponse is the response for promoted purchase relationship endpoints.
type SubscriptionPromotedPurchaseLinkageResponse struct {
	Data  ResourceData `json:"data"`
	Links Links        `json:"links"`
}

// SubscriptionSubscriptionAvailabilityLinkageResponse is the response for subscription availability relationship endpoints.
type SubscriptionSubscriptionAvailabilityLinkageResponse struct {
	Data  ResourceData `json:"data"`
	Links Links        `json:"links"`
}

// GetSubscriptionAvailabilityAvailableTerritoriesRelationships retrieves available territory linkages for an availability.
func (c *Client) GetSubscriptionAvailabilityAvailableTerritoriesRelationships(ctx context.Context, availabilityID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	availabilityID = strings.TrimSpace(availabilityID)
	if query.nextURL == "" && availabilityID == "" {
		return nil, fmt.Errorf("availabilityID is required")
	}

	path := fmt.Sprintf("/v1/subscriptionAvailabilities/%s/relationships/availableTerritories", availabilityID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionAvailabilityAvailableTerritoriesRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionGroupSubscriptionGroupLocalizationsRelationships retrieves localization linkages for a subscription group.
//
// Deprecated: Use GetSubscriptionGroupVersionLocalizationsRelationships with a subscription group version ID.
func (c *Client) GetSubscriptionGroupSubscriptionGroupLocalizationsRelationships(ctx context.Context, groupID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	groupID = strings.TrimSpace(groupID)
	if query.nextURL == "" && groupID == "" {
		return nil, fmt.Errorf("groupID is required")
	}

	path := fmt.Sprintf("/v1/subscriptionGroups/%s/relationships/subscriptionGroupLocalizations", groupID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionGroupLocalizationsRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionGroupSubscriptionsRelationships retrieves subscription linkages for a subscription group.
func (c *Client) GetSubscriptionGroupSubscriptionsRelationships(ctx context.Context, groupID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	groupID = strings.TrimSpace(groupID)
	if query.nextURL == "" && groupID == "" {
		return nil, fmt.Errorf("groupID is required")
	}

	path := fmt.Sprintf("/v1/subscriptionGroups/%s/relationships/subscriptions", groupID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionGroupSubscriptionsRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionAppStoreReviewScreenshotRelationship retrieves the review screenshot linkage for a subscription.
func (c *Client) GetSubscriptionAppStoreReviewScreenshotRelationship(ctx context.Context, subID string) (*SubscriptionAppStoreReviewScreenshotLinkageResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/appStoreReviewScreenshot", subID)
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionAppStoreReviewScreenshotLinkageResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionImagesRelationships retrieves image linkages for a subscription.
//
// Deprecated: Use GetSubscriptionVersionImagesRelationships with a subscription version ID.
func (c *Client) GetSubscriptionImagesRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/images", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionImagesRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionIntroductoryOffersRelationships retrieves introductory offer linkages for a subscription.
func (c *Client) GetSubscriptionIntroductoryOffersRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/introductoryOffers", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionIntroductoryOffersRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// RemoveSubscriptionIntroductoryOffers removes introductory offer relationships from a subscription.
func (c *Client) RemoveSubscriptionIntroductoryOffers(ctx context.Context, subID string, offerIDs []string) error {
	subID = strings.TrimSpace(subID)
	offerIDs = normalizeList(offerIDs)
	if subID == "" {
		return fmt.Errorf("subscription ID is required")
	}
	if len(offerIDs) == 0 {
		return fmt.Errorf("offerIDs are required")
	}

	payload := RelationshipRequest{
		Data: make([]RelationshipData, len(offerIDs)),
	}
	for i, id := range offerIDs {
		payload.Data[i] = RelationshipData{
			Type: ResourceTypeSubscriptionIntroductoryOffers,
			ID:   id,
		}
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return err
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/introductoryOffers", subID)
	_, err = c.do(ctx, http.MethodDelete, path, body)
	return err
}

// GetSubscriptionOfferCodesRelationships retrieves offer code linkages for a subscription.
func (c *Client) GetSubscriptionOfferCodesRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/offerCodes", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionOfferCodesRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionPricePointsRelationships retrieves price point linkages for a subscription.
func (c *Client) GetSubscriptionPricePointsRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/pricePoints", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionPricePointsRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionPricesRelationships retrieves price linkages for a subscription.
func (c *Client) GetSubscriptionPricesRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/prices", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionPricesRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// RemoveSubscriptionPrices removes price relationships from a subscription.
func (c *Client) RemoveSubscriptionPrices(ctx context.Context, subID string, priceIDs []string) error {
	subID = strings.TrimSpace(subID)
	priceIDs = normalizeList(priceIDs)
	if subID == "" {
		return fmt.Errorf("subscription ID is required")
	}
	if len(priceIDs) == 0 {
		return fmt.Errorf("priceIDs are required")
	}

	payload := RelationshipRequest{
		Data: make([]RelationshipData, len(priceIDs)),
	}
	for i, id := range priceIDs {
		payload.Data[i] = RelationshipData{
			Type: ResourceTypeSubscriptionPrices,
			ID:   id,
		}
	}

	body, err := BuildRequestBody(payload)
	if err != nil {
		return err
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/prices", subID)
	_, err = c.do(ctx, http.MethodDelete, path, body)
	return err
}

// GetSubscriptionPromotedPurchaseRelationship retrieves the promoted purchase linkage for a subscription.
func (c *Client) GetSubscriptionPromotedPurchaseRelationship(ctx context.Context, subID string) (*SubscriptionPromotedPurchaseLinkageResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/promotedPurchase", subID)
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionPromotedPurchaseLinkageResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionPromotionalOffersRelationships retrieves promotional offer linkages for a subscription.
func (c *Client) GetSubscriptionPromotionalOffersRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/promotionalOffers", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionPromotionalOffersRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionSubscriptionAvailabilityRelationship retrieves the subscription availability linkage for a subscription.
func (c *Client) GetSubscriptionSubscriptionAvailabilityRelationship(ctx context.Context, subID string) (*SubscriptionSubscriptionAvailabilityLinkageResponse, error) {
	subID = strings.TrimSpace(subID)
	if subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/subscriptionAvailability", subID)
	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response SubscriptionSubscriptionAvailabilityLinkageResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}

// GetSubscriptionSubscriptionLocalizationsRelationships retrieves subscription localization linkages for a subscription.
//
// Deprecated: Use GetSubscriptionVersionLocalizationsRelationships with a subscription version ID.
func (c *Client) GetSubscriptionSubscriptionLocalizationsRelationships(ctx context.Context, subID string, opts ...LinkagesOption) (*LinkagesResponse, error) {
	query := &linkagesQuery{}
	for _, opt := range opts {
		opt(query)
	}

	subID = strings.TrimSpace(subID)
	if query.nextURL == "" && subID == "" {
		return nil, fmt.Errorf("subscription ID is required")
	}

	path := fmt.Sprintf("/v1/subscriptions/%s/relationships/subscriptionLocalizations", subID)
	if query.nextURL != "" {
		if err := validateNextURL(query.nextURL); err != nil {
			return nil, fmt.Errorf("subscriptionSubscriptionLocalizationsRelationships: %w", err)
		}
		path = query.nextURL
	} else if queryString := buildLinkagesQuery(query); queryString != "" {
		path += "?" + queryString
	}

	data, err := c.do(ctx, http.MethodGet, path, nil)
	if err != nil {
		return nil, err
	}

	var response LinkagesResponse
	if err := json.Unmarshal(data, &response); err != nil {
		return nil, fmt.Errorf("failed to parse response: %w", err)
	}

	return &response, nil
}
